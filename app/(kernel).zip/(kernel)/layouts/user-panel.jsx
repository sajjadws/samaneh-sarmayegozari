import { Suspense } from "react";
import { authorize } from "@/lib/rbac";
import UserLayoutClient from "./user-layout-client";

async function UserPanelContent({ children }) {
    const access = await authorize();

    const clientAccess = JSON.parse(
        JSON.stringify({
            roles: access.roles,
            permissions: access.permissions,
            isSuperAdmin: access.isSuperAdmin,
        })
    );

    return (
        <UserLayoutClient access={clientAccess}>
            {children}
        </UserLayoutClient>
    );
}

export default function UserPanel({ children }) {
    return (
        <Suspense
            fallback={
                <div className="w-100 h-100 d-flex align-items-center justify-content-center">
                    در حال دریافت اطلاعات...
                </div>
            }
        >
            <UserPanelContent>
                {children}
            </UserPanelContent>
        </Suspense>
    );
}