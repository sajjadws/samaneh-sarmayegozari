import UserPanel from "@/app/(kernel)/layouts/user-panel";

export default function RolesLayout({ children }) {
    return <UserPanel>{children}</UserPanel>;
}
