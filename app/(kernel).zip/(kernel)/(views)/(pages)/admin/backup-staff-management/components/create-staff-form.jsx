"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { createStaff } from "../actions/create-staff";

const initialValues = {
	firstName: "",
	lastName: "",
	phoneNumber: "",
	email: "",
	password: "",
	roleId: "",
};

export default function CreateStaffForm({ roles }) {
	const router = useRouter();
	const [values, setValues] = useState(initialValues);
	const [busy, setBusy] = useState(false);
	const [message, setMessage] = useState("");
	const [error, setError] = useState(false);

	function update(field, value) {
		setValues((current) => ({ ...current, [field]: value }));
	}

	async function handleSubmit(event) {
		event.preventDefault();
		setBusy(true);
		setMessage("");
		setError(false);

		try {
			const result = await createStaff(values);
			if (!result.ok) {
				setError(true);
				setMessage(result.message || "خطا در ثبت اطلاعات");
				return;
			}
			setMessage(result.message);
			setValues(initialValues);
			router.push("/admin/staff-management");
			router.refresh();
		} catch {
			setError(true);
			setMessage("ارتباط با سرور برقرار نشد. دوباره تلاش کنید.");
		} finally {
			setBusy(false);
		}
	}

	const inputClass = "form-control w-100";

	return (
		<form onSubmit={handleSubmit} className="w-100 d-flex flex-column gap-4" style={{ maxWidth: 680 }}>
			<div className="d-flex flex-column gap-2">
				<label htmlFor="firstName">نام</label>
				<input id="firstName" className={inputClass} value={values.firstName} onChange={(e) => update("firstName", e.target.value)} required />
			</div>
			<div className="d-flex flex-column gap-2">
				<label htmlFor="lastName">نام خانوادگی</label>
				<input id="lastName" className={inputClass} value={values.lastName} onChange={(e) => update("lastName", e.target.value)} required />
			</div>
			<div className="d-flex flex-column gap-2">
				<label htmlFor="phoneNumber">شماره موبایل</label>
				<input id="phoneNumber" type="tel" dir="ltr" className={inputClass} value={values.phoneNumber} onChange={(e) => update("phoneNumber", e.target.value)} required />
			</div>
			<div className="d-flex flex-column gap-2">
				<label htmlFor="email">نام کاربری (ایمیل)</label>
				<input id="email" type="email" dir="ltr" autoComplete="username" className={inputClass} value={values.email} onChange={(e) => update("email", e.target.value)} required />
			</div>
			<div className="d-flex flex-column gap-2">
				<label htmlFor="password">رمز عبور</label>
				<input id="password" type="password" dir="ltr" autoComplete="new-password" minLength={8} className={inputClass} value={values.password} onChange={(e) => update("password", e.target.value)} required />
				<small>حداقل ۸ کاراکتر</small>
			</div>
			<div className="d-flex flex-column gap-2">
				<label htmlFor="roleId">نقش کارمند</label>
				<select id="roleId" className={inputClass} value={values.roleId} onChange={(e) => update("roleId", e.target.value)} required>
					<option value="">انتخاب نقش</option>
					{roles.map((role) => (
						<option key={role.id} value={role.id}>{role.title || role.name}</option>
					))}
				</select>
				{roles.length === 0 && <small>هیچ نقشی برای انتخاب وجود ندارد؛ ابتدا نقش‌ها را در بخش مدیریت نقش‌ها تعریف کنید.</small>}
			</div>

			{message && <p role="alert" style={{ color: error ? "#c62828" : "#2e7d32" }}>{message}</p>}

			<div className="d-flex align-items-center gap-3">
				<button type="submit" className="btn btn-primary" disabled={busy || roles.length === 0}>
					{busy ? "در حال ذخیره..." : "ذخیره و ایجاد کارمند"}
				</button>
				<Link href="/admin/staff-management">انصراف</Link>
			</div>
		</form>
	);
}
