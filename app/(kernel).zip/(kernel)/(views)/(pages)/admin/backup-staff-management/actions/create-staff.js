"use server";

import { auth } from "@/lib/authentication/auth";
import prismaDB from "@/lib/prisma/prismaDB";
import { headers } from "next/headers";
import { revalidatePath } from "next/cache";

async function requireAdmin() {
	const session = await auth.api.getSession({ headers: await headers() });
	if (!session?.user?.id) return null;

	const assignment = await prismaDB.userRole.findUnique({
		where: { userId: session.user.id },
		select: { role: { select: { name: true, isSuperAdmin: true } } },
	});

	const role = assignment?.role;
	if (!role || (!role.isSuperAdmin && !["ADMIN", "SUPER_ADMIN"].includes(role.name))) {
		return null;
	}
	return session.user;
}

export async function createStaff(values) {
	// const admin = await requireAdmin();
	// if (!admin) {
	// 	return { ok: false, status: 403, message: "اجازه انجام این عملیات را ندارید." };
	// }

	const parsed = staffSchema.safeParse(values);
	if (!parsed.success) {
		return {
			ok: false,
			status: 400,
			message: "اطلاعات واردشده معتبر نیست.",
			errors: parsed.error.flatten().fieldErrors,
		};
	}

	const data = parsed.data;
	const email = data.email.toLowerCase();
	const role = await prismaDB.role.findUnique({
		where: { id: data.roleId },
		select: { id: true, isSuperAdmin: true },
	});

	if (!role || role.isSuperAdmin) {
		return { ok: false, status: 400, message: "نقش انتخاب‌شده معتبر نیست." };
	}

	const existing = await prismaDB.user.findFirst({
		where: { OR: [{ email }, { username: email }, { phoneNumber: data.phoneNumber }] },
		select: { id: true },
	});
	if (existing) {
		return {
			ok: false,
			status: 409,
			message: "این ایمیل یا شماره موبایل قبلاً ثبت شده است.",
		};
	}

	try {
		// Create through Better Auth so the password is hashed and stored in its
		// credential account in the same format used by signInEmail at /admin/login.
		const result = await auth.api.signUpEmail({
			body: {
				email,
				name: `${data.firstName} ${data.lastName}`,
				password: data.password,
			},
			headers: await headers(),
		});

		const newUserId = result?.user?.id;
		if (!newUserId) {
			return { ok: false, status: 500, message: "ساخت حساب کارمند انجام نشد." };
		}

		await prismaDB.$transaction([
			prismaDB.user.update({
				where: { id: newUserId },
				data: {
					phoneNumber: data.phoneNumber,
					username: email,
					displayUsername: email,
				},
			}),
			prismaDB.userRole.create({
				data: {
					userId: newUserId,
					roleId: role.id,
					assignedBy: admin.id,
				},
			}),
		]);

		revalidatePath("/admin/staff-management");
		return {
			ok: true,
			status: 201,
			message: "کارمند با موفقیت ایجاد شد. اکنون می‌تواند با ایمیل و رمز عبور خود وارد شود.",
		};
	} catch (error) {
		console.error("[CREATE_STAFF_ERROR]", error);
		return {
			ok: false,
			status: 500,
			message: "ایجاد کارمند انجام نشد. ایمیل را بررسی کنید و دوباره تلاش کنید.",
		};
	}
}
