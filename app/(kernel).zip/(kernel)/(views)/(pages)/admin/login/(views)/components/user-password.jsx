"use server";

import { auth } from "@/lib/authentication/auth";

// Signup
// export async function signup() {
// 	console.log("object");
// 	return await auth.api.signUpEmail({
// 		body: {
// 			email: "email@domain.com",
// 			name: "Test User",
// 			password: "password1234",
// 			username: "test",
// 			displayUsername: "Test User123",
// 		},
// 	});
// }

// Login
export async function login({ email, password }) {
	// return await auth.api.signInEmail({
	return await auth.api.signInUsername({
		body: {
			email,
			password,
		},
	});
}