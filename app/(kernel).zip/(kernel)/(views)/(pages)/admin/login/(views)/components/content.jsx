"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import useLoginClient from "@/lib/authentication/is-login-client";
import { login, signup } from "./user-password";
import { Controller, useForm } from "react-hook-form";
import { authClient } from "@/lib/authentication/auth-client";

export default function ContentPage() {
	const router = useRouter();
	const { session, isPending } = useLoginClient();
	const form = useForm({
		// resolver: zodResolver(phoneNumberSchema),
		// defaultValues: {
		//     phoneNumber,
		// },
		mode: "onChange",
	});

	useEffect(() => {
		if (!isPending && !session) {
			router.replace("/user/login");
		}
	}, [session, isPending, router]);

	if (isPending || !session) {
		return null;
	}

	// async function handleSignup() {
	// 	try {
	// 		const result = await signup();
	// 		console.log("Signup:", result);
	// 	} catch (error) {
	// 		console.error(error);
	// 	}
	// }

	// async function handleLogin(values) {
	// 	try {
	// 		const result = await login(values);
	// 		console.log("Login:", result);
	// 	} catch (error) {
	// 		console.error(error);
	// 	}
	// }
	async function handleSignup(values) {
		const { data, error } = await authClient.signUp.email({
			name: "Hossein",
			email: "hossein@example.com",
			username: "hossein",
			password: "123456789",
			displayUsername: "hossein"
		});

		console.log("error", error);
		console.log("data", data);
	}
	async function handleLogin(values) {
		const { data, error } = await authClient.signIn.username({
			username: values.userName, // required, The username of the user.
			password: values.password, // required, The password of the user.
		});

		console.log("error", error);
		console.log("data", data);

		
	}

	return (
		<div className="w-100 d-flex flex-column justify-content-center align-items-center">
			{/* <h1>hossein</h1> */}
			<button onClick={handleSignup}>
                Signup
            </button>

			{/* <button onClick={handleLogin}>
                Login
            </button> */}
			<form
				className="d-flex flex-column justify-content-center align-items-center"
				onSubmit={form.handleSubmit(handleLogin)}
			>
				<Controller
					name="userName"
					control={form.control}
					defaultValue="hossein"
					render={({ field, fieldState }) => <input type="text" {...field} />}
				/>

				<Controller
					name="password"
					control={form.control}
					defaultValue="123456789"
					render={({ field, fieldState }) => <input type="password" {...field} />}
				/>

				<button type="submit">Login</button>
			</form>
		</div>
	);
}
