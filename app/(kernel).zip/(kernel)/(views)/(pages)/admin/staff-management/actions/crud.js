"use server";

import prismaDB from "@/lib/prisma/prismaDB";
import { authorize } from "@/lib/rbac/authorize";
import { revalidatePath } from "next/cache";
import { z } from "zod";

const userSchema = z.object({
	name: z
		.string()
		.trim()
		.min(2)
		.max(60)
		.regex(/^[a-z][a-z0-9_-]*$/),
	title: z.string().trim().min(2).max(100),
	description: z.string().trim().max(500).optional().nullable(),
});
const permissionAssignmentSchema = z.object({
	permissionId: z.string().min(1),
	scope: z.enum(["OWN", "GLOBAL"]).nullable().optional(),
});
const userPermissionsSchema = z.array(permissionAssignmentSchema);
const result = (ok, status, message, data = null, errors = null) => ({ ok, status, message, data, errors });
const usersPath = "/admin/users";

export async function getAllUsers(options = {}) {
	// try {
		await authorize({ permission: "users.read" });
		const page = Math.max(1, Number(options.page) || 1);
		const perPage = Math.min(100, Math.max(1, Number(options.perPage) || 10));
		const q = String(options.q || "").trim();
		const where = q
		? { OR: [{ name: { contains: q } }, { title: { contains: q } }, { description: { contains: q } }] }
		: {};
		const [total, data] = await Promise.all([
			prismaDB.user.count({ where }),
			prismaDB.user.findMany({
				where,
				orderBy: { createdAt: "desc" },
				skip: (page - 1) * perPage,
				take: perPage,
				// include: { _count: { select: { users: true, permissions: true } } },
				include: { _count: { select: { users: true, permissions: true } } },
			}),
		]);
		console.log("object2");
		return result(true, 200, "نقش‌ها دریافت شدند", { data, total, page, perPage });
	// } catch (error) {
	// 	return result(
	// 		false,
	// 		error.status || 500,
	// 		error.status === 401 ? "ابتدا وارد حساب شوید" : "دریافت نقش‌ها ناموفق بود",
	// 	);
	// }
}

export async function getUserDetails(id) {
	try {
		await authorize({ permission: "users.read" });
		if (!id) return result(false, 400, "شناسه نقش الزامی است");
		const user = await prismaDB.user.findUnique({
			where: { id },
			include: { permissions: { include: { permission: true } } },
		});
		if (!user) return result(false, 404, "نقش پیدا نشد");
		return result(true, 200, "اطلاعات نقش دریافت شد", user);
	} catch (error) {
		return result(false, error.status || 500, "دسترسی یا دریافت اطلاعات ناموفق بود");
	}
}

export async function getPermissionCatalog() {
	try {
		await authorize({ permission: "permissions.read" });
		const data = await prismaDB.permission.findMany({ orderBy: { name: "asc" } });
		return result(true, 200, "مجوزها دریافت شدند", data);
	} catch (error) {
		return result(false, error.status || 500, "دریافت مجوزها ناموفق بود");
	}
}

export async function createUser(values) {
	try {
		await authorize({ permission: "users.create" });
		const parsed = userSchema.safeParse(values);
		if (!parsed.success)
			return result(false, 400, "اطلاعات نقش معتبر نیست", null, parsed.error.flatten().fieldErrors);
		const user = await prismaDB.user.create({ data: parsed.data });
		revalidatePath(usersPath);
		return result(true, 201, "نقش ایجاد شد", user);
	} catch (error) {
		if (error.code === "P2002") return result(false, 409, "نام این نقش قبلاً ثبت شده است");
		return result(false, error.status || 500, "ایجاد نقش ناموفق بود");
	}
}

export async function updateUser(id, values, assignments = []) {
	try {
		await authorize({ permission: "users.update" });
		if (!id) return result(false, 400, "شناسه نقش الزامی است");
		const parsed = userSchema.safeParse(values);
		const parsedAssignments = userPermissionsSchema.safeParse(assignments);
		if (!parsed.success || !parsedAssignments.success)
			return result(false, 400, "اطلاعات ارسالی معتبر نیست", null, {
				...(parsed.success ? {} : parsed.error.flatten().fieldErrors),
				...(parsedAssignments.success ? {} : { userPermission: parsedAssignments.error.flatten() }),
			});
		const current = await prismaDB.user.findUnique({
			where: { id },
			include: { userPermission: { include: { permission: true } } },
		});
		if (!current) return result(false, 404, "نقش پیدا نشد");
		if (current.isSystem && (parsed.data.name !== current.name || parsed.data.title !== current.title))
			return result(false, 403, "مشخصات اصلی نقش سیستمی قابل تغییر نیست");
		if (current.isSuperAdmin) return result(false, 403, "مجوزهای نقش مدیر کل قابل تغییر نیست");
		const ids = parsedAssignments.data.map((item) => item.permissionId);
		if (new Set(ids).size !== ids.length) return result(false, 400, "مجوز تکراری ارسال شده است");
		const userPermission = ids.length
			? await prismaDB.permission.findMany({ where: { id: { in: ids } }, select: { id: true, name: true } })
			: [];
		if (userPermission.length !== ids.length) return result(false, 400, "یک یا چند مجوز معتبر نیستند");
		const nameById = new Map(userPermission.map((item) => [item.id, item.name]));
		for (const item of parsedAssignments.data) {
			const isRead = nameById.get(item.permissionId)?.endsWith(".read");
			if (isRead && !["OWN", "GLOBAL"].includes(item.scope))
				return result(false, 400, "برای مجوز مشاهده باید Scope انتخاب شود");
			if (!isRead && item.scope != null) return result(false, 400, "Scope فقط برای مجوزهای مشاهده مجاز است");
		}
		const updated = await prismaDB.$transaction(async (tx) => {
			await tx.user.update({ where: { id }, data: parsed.data });
			await tx.userPermission.deleteMany({ where: { userId: id } });
			if (parsedAssignments.data.length)
				await tx.userPermission.createMany({
					data: parsedAssignments.data.map((item) => ({
						userId: id,
						permissionId: item.permissionId,
						scope: item.scope ?? null,
					})),
				});
			return tx.user.findUnique({ where: { id }, include: { userPermission: { include: { permission: true } } } });
		});
		revalidatePath(usersPath);
		return result(true, 200, "نقش و دسترسی‌ها به‌روزرسانی شدند", updated);
	} catch (error) {
		if (error.code === "P2002") return result(false, 409, "نام این نقش قبلاً ثبت شده است");
		return result(false, error.status || 500, "ویرایش نقش ناموفق بود");
	}
}

export async function deleteUser(id) {
	try {
		await authorize({ permission: "users.delete" });
		if (!id) return result(false, 400, "شناسه نقش الزامی است");
		const user = await prismaDB.user.findUnique({ where: { id } });
		if (!user) return result(false, 404, "نقش پیدا نشد");
		if (user.isSystem || user.isSuperAdmin) return result(false, 403, "نقش سیستمی قابل حذف نیست");
		await prismaDB.user.delete({ where: { id } });
		revalidatePath(usersPath);
		return result(true, 200, "نقش حذف شد");
	} catch (error) {
		return result(false, error.status || 500, "حذف نقش ناموفق بود");
	}
}

export async function assignUserPermission(userId, permissionId) {
	try {
		const actor = await authorize({ permission: "roles.assign" });
		if (!userId || !permissionId) return result(false, 400, "کاربر و نقش الزامی هستند");
		const permission = await prismaDB.permission.findUnique({ where: { id: permissionId }, select: { id: true } });
		if (!permission) return result(false, 404, "نقش پیدا نشد");
		const assignment = await prismaDB.userRole.upsert({
			where: { userId },
			update: { permissionId, assignedBy: actor.user.id },
			create: { userId, permissionId, assignedBy: actor.user.id },
		});
		revalidatePath(rolesPath);
		return result(true, 200, "نقش کاربر به‌روزرسانی شد", assignment);
	} catch (error) {
		return result(false, error.status || 500, "تخصیص نقش ناموفق بود");
	}
}
