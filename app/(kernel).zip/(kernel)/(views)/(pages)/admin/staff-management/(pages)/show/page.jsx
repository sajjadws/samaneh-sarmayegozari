import { DataTable } from "@/miz/themes/react/components/data-table/data-table";
import { connection } from "next/server";
import { getAllUsers } from "../../actions/crud";
import { columns } from "../../components/columns";
import useLoginServer from "@/lib/authentication/is-login-server";

export async function ShowUsers({ searchParams }){
        await connection();
        const { page, perPage, q = "", role } = await searchParams;
        const { user } = await useLoginServer();
    
        const fetchData = await getAllUsers(user?.id, {
            page: +page ? +page : 1,
            perPage: +perPage ? +perPage : 10,
            q: q || "",
            role: role || null,
        });
        const fetchedData = fetchData.data;
        console.log(fetchData);
        const { data, ...otherData } = fetchedData;

    return (
        <DataTable className="w-100 h-100 shadow-lg " singleName="کاربر" collectionName="کاربران" columns={columns} data={data} option={otherData} total={otherData?.total || 0} />
    );
}